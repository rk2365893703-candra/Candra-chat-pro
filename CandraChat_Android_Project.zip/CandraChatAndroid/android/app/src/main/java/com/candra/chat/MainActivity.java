package com.candra.chat;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root, content; SharedPreferences prefs;
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView text(String s, float size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY); t.setPadding(dp(16),dp(10),dp(16),dp(10)); return t; }
    Button button(String s){ Button b=new Button(this); b.setText(s); return b; }
    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("candra",0); showHome(); }
    void base(){ root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); root.addView(content,new LinearLayout.LayoutParams(-1,-1)); setContentView(root); }
    void showHome(){ base(); TextView title=text("Candra Chat",28); title.setGravity(Gravity.CENTER); content.addView(title); content.addView(text("Simple Android chat app starter",18));
        Button login=button("Login"); login.setOnClickListener(v->showLogin()); content.addView(login);
        Button signup=button("Create account"); signup.setOnClickListener(v->showSignup()); content.addView(signup); }
    void showLogin(){ base(); content.addView(text("Login",26)); EditText email=new EditText(this); email.setHint("Email or mobile"); content.addView(email); EditText pass=new EditText(this); pass.setHint("Password"); pass.setInputType(0x81); content.addView(pass); Button b=button("Login"); b.setOnClickListener(v->{ if(email.getText().length()>0 && pass.getText().length()>0){ prefs.edit().putBoolean("logged",true).apply(); showChat(); } else Toast.makeText(this,"Enter login details",Toast.LENGTH_SHORT).show(); }); content.addView(b); Button back=button("Back"); back.setOnClickListener(v->showHome()); content.addView(back); }
    void showSignup(){ base(); content.addView(text("Create account",26)); EditText name=new EditText(this); name.setHint("Name"); content.addView(name); EditText email=new EditText(this); email.setHint("Email or mobile"); content.addView(email); EditText pass=new EditText(this); pass.setHint("Password"); pass.setInputType(0x81); content.addView(pass); Button b=button("Sign up"); b.setOnClickListener(v->{ if(name.getText().length()>0 && email.getText().length()>0 && pass.getText().length()>0){ prefs.edit().putBoolean("logged",true).putString("name",name.getText().toString()).apply(); showChat(); } else Toast.makeText(this,"Fill all fields",Toast.LENGTH_SHORT).show(); }); content.addView(b); Button back=button("Back"); back.setOnClickListener(v->showHome()); content.addView(back); }
    void showChat(){ base(); content.addView(text("Candra Chat",26)); TextView messages=text("Welcome! Your local chat screen is ready.\n\nThis starter stores login state on this phone. A real multi-user chat needs a server/database next.",17); content.addView(messages,new LinearLayout.LayoutParams(-1,0,1)); LinearLayout row=new LinearLayout(this); EditText input=new EditText(this); input.setHint("Type a message"); row.addView(input,new LinearLayout.LayoutParams(0,-2,1)); Button send=button("Send"); send.setOnClickListener(v->{ if(input.getText().length()>0){ messages.append("\n\nYou: "+input.getText()); input.setText(""); }}); row.addView(send); content.addView(row); Button logout=button("Logout"); logout.setOnClickListener(v->{prefs.edit().clear().apply();showHome();}); content.addView(logout); }
}
